from django.urls import path
from . import views
from .views import index


urlpatterns = [
    path('',views.index),  
    path('<int:id>/',views.detailView,name='detail-view'),
    path('checkout/',views.checkoutPage, name='checkout-page'),
    
]